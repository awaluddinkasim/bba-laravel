<h1 <?php echo e($attributes->merge(['class' => 'font-bold text-xl'])); ?>>
    <?php echo e($slot); ?>

</h1>
<?php /**PATH D:\Data\laragon\Web\bba\resources\views/components/elements/title.blade.php ENDPATH**/ ?>
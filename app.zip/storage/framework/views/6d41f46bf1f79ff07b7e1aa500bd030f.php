<?php $__env->startPush('styles'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('assets/libs/datatable/datatables.min.css')); ?>">
<?php $__env->stopPush(); ?>

<?php $__env->startPush('scripts'); ?>
    <script src="<?php echo e(asset('assets/libs/datatable/datatables.min.js')); ?>"></script>
    <script>
        new DataTable("#datatable", {
            ordering: false,
            lengthChange: false
        })

        function deleteData() {
            Swal.fire({
                title: "Anda yakin?",
                text: "Data yang terhapus tak dapat dikembalikan!",
                icon: "warning",
                showCancelButton: true,
                confirmButtonColor: "#d33",
                confirmButtonText: "Hapus!",
                cancelButtonText: "Batal"
            }).then((result) => {
                if (result.isConfirmed) {
                    $('#deleteForm').submit()
                }
            })
        }
    </script>
<?php $__env->stopPush(); ?>

<?php if (isset($component)) { $__componentOriginal23a33f287873b564aaf305a1526eada4 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal23a33f287873b564aaf305a1526eada4 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.layout','data' => ['title' => 'Daftar Pengguna']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'Daftar Pengguna']); ?>
    <?php if (isset($component)) { $__componentOriginal4ed2e8f0d769c9d71ea4d41372d8c752 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal4ed2e8f0d769c9d71ea4d41372d8c752 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.elements.card','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('elements.card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
        <table id="datatable" class="display" style="width:100%">
            <thead>
                <tr>
                    <th>#</th>
                    <th>Nama</th>
                    <th>Email</th>
                    <th>Jenis Kelamin</th>
                    <th>No. HP</th>
                    <th></th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($loop->iteration); ?></td>
                        <td><?php echo e($user->nama); ?></td>
                        <td><?php echo e($user->email); ?></td>
                        <td><?php echo e($user->jk); ?></td>
                        <td><?php echo e($user->no_hp); ?></td>
                        <td>
                            <button class="btn bg-success text-white rounded"
                                onclick="document.location.href = '<?php echo e(route('users.edit', $user->id)); ?>'">
                                <i class="uil uil-edit"></i>
                            </button>
                            <form action="<?php echo e(route('users.delete', $user->id)); ?>" method="post" id="deleteForm"
                                style="display: inline">
                                <?php echo method_field('DELETE'); ?>
                                <?php echo csrf_field(); ?>
                                <button type="button" class="btn bg-danger text-white rounded" onclick="deleteData()">
                                    <i class="uil uil-trash"></i>
                                </button>
                            </form>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal4ed2e8f0d769c9d71ea4d41372d8c752)): ?>
<?php $attributes = $__attributesOriginal4ed2e8f0d769c9d71ea4d41372d8c752; ?>
<?php unset($__attributesOriginal4ed2e8f0d769c9d71ea4d41372d8c752); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal4ed2e8f0d769c9d71ea4d41372d8c752)): ?>
<?php $component = $__componentOriginal4ed2e8f0d769c9d71ea4d41372d8c752; ?>
<?php unset($__componentOriginal4ed2e8f0d769c9d71ea4d41372d8c752); ?>
<?php endif; ?>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal23a33f287873b564aaf305a1526eada4)): ?>
<?php $attributes = $__attributesOriginal23a33f287873b564aaf305a1526eada4; ?>
<?php unset($__attributesOriginal23a33f287873b564aaf305a1526eada4); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal23a33f287873b564aaf305a1526eada4)): ?>
<?php $component = $__componentOriginal23a33f287873b564aaf305a1526eada4; ?>
<?php unset($__componentOriginal23a33f287873b564aaf305a1526eada4); ?>
<?php endif; ?>
<?php /**PATH D:\Data\laragon\Web\bba\resources\views/pages/users.blade.php ENDPATH**/ ?>
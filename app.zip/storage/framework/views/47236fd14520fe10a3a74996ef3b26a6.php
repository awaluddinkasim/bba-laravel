<?php if (isset($component)) { $__componentOriginal23a33f287873b564aaf305a1526eada4 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal23a33f287873b564aaf305a1526eada4 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.layout','data' => ['title' => 'Percakapan Harian']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'Percakapan Harian']); ?>
    <div class="flex flex-row justify-between items-center mb-3">
        <?php if (isset($component)) { $__componentOriginalca77f12175cc09adad5611cdec5ad84f = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalca77f12175cc09adad5611cdec5ad84f = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.elements.title','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('elements.title'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
            Daftar Percakapan Harian
         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalca77f12175cc09adad5611cdec5ad84f)): ?>
<?php $attributes = $__attributesOriginalca77f12175cc09adad5611cdec5ad84f; ?>
<?php unset($__attributesOriginalca77f12175cc09adad5611cdec5ad84f); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalca77f12175cc09adad5611cdec5ad84f)): ?>
<?php $component = $__componentOriginalca77f12175cc09adad5611cdec5ad84f; ?>
<?php unset($__componentOriginalca77f12175cc09adad5611cdec5ad84f); ?>
<?php endif; ?>

        <?php if (isset($component)) { $__componentOriginalad722ce44e9356a1c37f576a13515067 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalad722ce44e9356a1c37f576a13515067 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.elements.form-modal','data' => ['title' => 'Percakapan Harian','action' => ''.e(route('percakapan-harian.store')).'','hasFile' => true]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('elements.form-modal'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'Percakapan Harian','action' => ''.e(route('percakapan-harian.store')).'','hasFile' => true]); ?>
            <div class="mb-3">
                <label for="kalimatInput" class="text-gray-800 text-sm font-medium inline-block mb-2">Kalimat (Bahasa
                    Indonesia)</label>
                <textarea name="kalimat" id="kalimatInput" rows="3" class="form-input <?php $__errorArgs = ['kalimat'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-danger <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                    required></textarea>
            </div>
            <div class="mb-3">
                <label for="audioInput" class="text-gray-800 text-sm font-medium inline-block mb-2">
                    Audio
                </label>
                <input type="file" name="audio" id="audioInput" accept="audio/*"
                    class="form-input <?php $__errorArgs = ['audio'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-danger <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required>
            </div>
         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalad722ce44e9356a1c37f576a13515067)): ?>
<?php $attributes = $__attributesOriginalad722ce44e9356a1c37f576a13515067; ?>
<?php unset($__attributesOriginalad722ce44e9356a1c37f576a13515067); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalad722ce44e9356a1c37f576a13515067)): ?>
<?php $component = $__componentOriginalad722ce44e9356a1c37f576a13515067; ?>
<?php unset($__componentOriginalad722ce44e9356a1c37f576a13515067); ?>
<?php endif; ?>
    </div>

    <?php $__empty_1 = true; $__currentLoopData = $daftarPercakapanHarian; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $percakapanHarian): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <div class="card p-5 rounded cursor-pointer mb-3"
            onclick="document.location.href = '<?php echo e(route('percakapan-harian.show', $percakapanHarian->id)); ?>'">
            <p class="text-xl mb-4">
                <?php echo e($percakapanHarian->kalimat); ?>

            </p>

            <p class="font-bold text-black text-4xl">
                <?php echo e($percakapanHarian->arab); ?>

            </p>
            <p class="text-xl">
                <?php echo e($percakapanHarian->latin); ?>

            </p>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <div class="card text-center p-8 rounded-lg">
            Tidak ada data
        </div>
    <?php endif; ?>

    <?php echo e($daftarPercakapanHarian->links()); ?>


 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal23a33f287873b564aaf305a1526eada4)): ?>
<?php $attributes = $__attributesOriginal23a33f287873b564aaf305a1526eada4; ?>
<?php unset($__attributesOriginal23a33f287873b564aaf305a1526eada4); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal23a33f287873b564aaf305a1526eada4)): ?>
<?php $component = $__componentOriginal23a33f287873b564aaf305a1526eada4; ?>
<?php unset($__componentOriginal23a33f287873b564aaf305a1526eada4); ?>
<?php endif; ?>
<?php /**PATH D:\Data\laragon\Web\bba\resources\views/pages/percakapan.blade.php ENDPATH**/ ?>
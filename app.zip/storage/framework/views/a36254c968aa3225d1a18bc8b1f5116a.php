<?php if (isset($component)) { $__componentOriginal23a33f287873b564aaf305a1526eada4 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal23a33f287873b564aaf305a1526eada4 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.layout','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <div class="grid lg:grid-cols-3 gap-3">
        <div class="card rounded-lg">
            <div class="p-5 flex items-center justify-between">
                <span>
                    <span class="text-slate-400 font-semibold block">Total Materi</span>
                    <span class="text-xl font-semibold"><span><?php echo e(number_format($materi)); ?></span></span>
                </span>

                <span
                    class="flex justify-center items-center h-14 w-14 bg-blue-600/5 shadow shadow-blue-600/5 text-blue-600">
                    <i class="uil uil-book text-xl"></i>
                </span>
            </div>
        </div>
        <div class="card rounded-lg">
            <div class="p-5 flex items-center justify-between">
                <span>
                    <span class="text-slate-400 font-semibold block">Total Kosakata</span>
                    <span class="text-xl font-semibold"><span><?php echo e(number_format($kosakata)); ?></span></span>
                </span>

                <span
                    class="flex justify-center items-center h-14 w-14 bg-blue-600/5 shadow shadow-blue-600/5 text-blue-600">
                    <i class="uil uil-hipchat text-xl"></i>
                </span>
            </div>
        </div>
        <div class="card rounded-lg">
            <div class="p-5 flex items-center justify-between">
                <span>
                    <span class="text-slate-400 font-semibold block">Total Percakapan Harian</span>
                    <span class="text-xl font-semibold"><span><?php echo e(number_format($percakapanHarian)); ?></span></span>
                </span>

                <span
                    class="flex justify-center items-center h-14 w-14 bg-blue-600/5 shadow shadow-blue-600/5 text-blue-600">
                    <i class="uil uil-comments text-xl"></i>
                </span>
            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal23a33f287873b564aaf305a1526eada4)): ?>
<?php $attributes = $__attributesOriginal23a33f287873b564aaf305a1526eada4; ?>
<?php unset($__attributesOriginal23a33f287873b564aaf305a1526eada4); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal23a33f287873b564aaf305a1526eada4)): ?>
<?php $component = $__componentOriginal23a33f287873b564aaf305a1526eada4; ?>
<?php unset($__componentOriginal23a33f287873b564aaf305a1526eada4); ?>
<?php endif; ?>
<?php /**PATH D:\Data\laragon\Web\bba\resources\views/pages/index.blade.php ENDPATH**/ ?>
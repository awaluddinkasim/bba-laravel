<script>
    function deleteData() {
        Swal.fire({
            title: "Anda yakin?",
            text: "Data yang terhapus tak dapat dikembalikan!",
            icon: "warning",
            showCancelButton: true,
            confirmButtonColor: "#d33",
            confirmButtonText: "Hapus!",
            cancelButtonText: "Batal"
        }).then((result) => {
            if (result.isConfirmed) {
                $('#deleteForm').submit()
            }
        })
    }
</script>

<?php if (isset($component)) { $__componentOriginal23a33f287873b564aaf305a1526eada4 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal23a33f287873b564aaf305a1526eada4 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.layout','data' => ['title' => ''.e($materi->judul).'']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => ''.e($materi->judul).'']); ?>
    <div class="flex flex-row justify-between mb-3">
        <button type="button" class="btn bg-primary text-white rounded"
            onclick="document.location.href = '<?php echo e(route('materi.index')); ?>'">
            <i class="uil uil-step-backward-alt"></i>
        </button>

        <div>
            <button type="button" class="btn bg-success text-white rounded"
                onclick="document.location.href = '<?php echo e(route('materi.edit', $materi->id)); ?>'">
                <i class="uil uil-edit"></i>
            </button>
            <form action="<?php echo e(route('materi.delete', $materi->id)); ?>" method="post" id="deleteForm"
                style="display: inline">
                <?php echo method_field('DELETE'); ?>
                <?php echo csrf_field(); ?>
                <button type="button" class="btn bg-danger text-white rounded" onclick="deleteData()">
                    <i class="uil uil-trash"></i>
                </button>
            </form>
        </div>
    </div>

    <div class="grid lg:grid-cols-5 gap-2">
        <div class="card p-5 rounded col-span-3">
            <h1 class="font-bold text-xl">
                <?php echo e($materi->judul); ?>

            </h1>
            <small>Dibuat pada <?php echo e(Carbon\Carbon::parse($materi->created_at)->isoFormat('DD MMMM YYYY')); ?> pukul
                <?php echo e(Carbon\Carbon::parse($materi->created_at)->isoFormat('HH:mm')); ?></small>
            <div class="mt-3">
                <?php echo $materi->konten; ?>

            </div>
        </div>
        <div class="card p-5 rounded col-span-2">
            <h1 class="font-bold text-xl mb-3">
                Video
            </h1>
            <?php echo e(explode('/', $materi->url_youtube)[array_key_last(explode('/', $materi->url_youtube))]); ?>

            <iframe src="<?php echo e($materi->url_youtube); ?>" height="300">
            </iframe>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal23a33f287873b564aaf305a1526eada4)): ?>
<?php $attributes = $__attributesOriginal23a33f287873b564aaf305a1526eada4; ?>
<?php unset($__attributesOriginal23a33f287873b564aaf305a1526eada4); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal23a33f287873b564aaf305a1526eada4)): ?>
<?php $component = $__componentOriginal23a33f287873b564aaf305a1526eada4; ?>
<?php unset($__componentOriginal23a33f287873b564aaf305a1526eada4); ?>
<?php endif; ?>
<?php /**PATH D:\Data\laragon\Web\bba\resources\views/pages/materi-detail.blade.php ENDPATH**/ ?>
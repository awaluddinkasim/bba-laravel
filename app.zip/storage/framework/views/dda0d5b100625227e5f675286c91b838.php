<?php $__env->startPush('styles'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('assets/libs/datatable/datatables.min.css')); ?>">
<?php $__env->stopPush(); ?>

<?php $__env->startPush('scripts'); ?>
    <script src="<?php echo e(asset('assets/libs/datatable/datatables.min.js')); ?>"></script>
    <script>
        new DataTable("#datatable", {
            ordering: false,
            lengthChange: false
        })
    </script>
<?php $__env->stopPush(); ?>

<?php if (isset($component)) { $__componentOriginal23a33f287873b564aaf305a1526eada4 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal23a33f287873b564aaf305a1526eada4 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.layout','data' => ['title' => 'Kosakata']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'Kosakata']); ?>
    <?php if (isset($component)) { $__componentOriginal4ed2e8f0d769c9d71ea4d41372d8c752 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal4ed2e8f0d769c9d71ea4d41372d8c752 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.elements.card','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('elements.card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
        <div class="flex justify-between items-center mb-4">
            <h2 class="font-semibold text-xl">Daftar Kosakata</h2>
            <?php if (isset($component)) { $__componentOriginalad722ce44e9356a1c37f576a13515067 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalad722ce44e9356a1c37f576a13515067 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.elements.form-modal','data' => ['title' => 'Kosakata','action' => ''.e(route('kosakata.store')).'','hasFile' => true]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('elements.form-modal'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'Kosakata','action' => ''.e(route('kosakata.store')).'','hasFile' => true]); ?>
                <div class="mb-3">
                    <label for="kataInput" class="text-gray-800 text-sm font-medium inline-block mb-2">Kata (Bahasa
                        Arab)</label>
                    <input type="text" id="kataInput" name="kata"
                        class="form-input <?php $__errorArgs = ['kata'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-danger <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required>
                </div>
                <div class="mb-3">
                    <label for="latinInput" class="text-gray-800 text-sm font-medium inline-block mb-2">Latin</label>
                    <input type="text" id="latinInput" name="latin"
                        class="form-input <?php $__errorArgs = ['latin'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-danger <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required>
                </div>
                <div class="mb-3">
                    <label for="artiInput" class="text-gray-800 text-sm font-medium inline-block mb-2">Arti</label>
                    <input type="text" id="artiInput" name="arti"
                        class="form-input <?php $__errorArgs = ['arti'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-danger <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required>
                </div>
                <div class="mb-3">
                    <label for="contohInput" class="text-gray-800 text-sm font-medium inline-block mb-2">Contoh
                        Kalimat</label>
                    <textarea name="contoh_kalimat" id="contohInput" rows="5"
                        class="form-input <?php $__errorArgs = ['contoh_kalimat'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-danger <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required></textarea>
                </div>
                <div class="mb-3">
                    <label for="audioInput" class="text-gray-800 text-sm font-medium inline-block mb-2">
                        Audio
                    </label>
                    <input type="file" name="audio" id="audioInput" accept="audio/*"
                        class="form-input <?php $__errorArgs = ['audio'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-danger <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required>
                </div>
             <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalad722ce44e9356a1c37f576a13515067)): ?>
<?php $attributes = $__attributesOriginalad722ce44e9356a1c37f576a13515067; ?>
<?php unset($__attributesOriginalad722ce44e9356a1c37f576a13515067); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalad722ce44e9356a1c37f576a13515067)): ?>
<?php $component = $__componentOriginalad722ce44e9356a1c37f576a13515067; ?>
<?php unset($__componentOriginalad722ce44e9356a1c37f576a13515067); ?>
<?php endif; ?>
        </div>

        <table id="datatable" class="display" style="width:100%">
            <thead>
                <tr>
                    <th>#</th>
                    <th>Kata</th>
                    <th>Latin</th>
                    <th>Arti</th>
                    <th></th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $daftarKosakata; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kosakata): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($loop->iteration); ?></td>
                        <td class="text-lg"><?php echo e($kosakata->kata); ?></td>
                        <td><?php echo e($kosakata->latin); ?></td>
                        <td><?php echo e($kosakata->arti); ?></td>
                        <td class="text-center">
                            <button class="btn bg-success text-white rounded"
                                onclick="document.location.href = '<?php echo e(route('kosakata.show', $kosakata->id)); ?>'">
                                Detail
                            </button>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal4ed2e8f0d769c9d71ea4d41372d8c752)): ?>
<?php $attributes = $__attributesOriginal4ed2e8f0d769c9d71ea4d41372d8c752; ?>
<?php unset($__attributesOriginal4ed2e8f0d769c9d71ea4d41372d8c752); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal4ed2e8f0d769c9d71ea4d41372d8c752)): ?>
<?php $component = $__componentOriginal4ed2e8f0d769c9d71ea4d41372d8c752; ?>
<?php unset($__componentOriginal4ed2e8f0d769c9d71ea4d41372d8c752); ?>
<?php endif; ?>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal23a33f287873b564aaf305a1526eada4)): ?>
<?php $attributes = $__attributesOriginal23a33f287873b564aaf305a1526eada4; ?>
<?php unset($__attributesOriginal23a33f287873b564aaf305a1526eada4); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal23a33f287873b564aaf305a1526eada4)): ?>
<?php $component = $__componentOriginal23a33f287873b564aaf305a1526eada4; ?>
<?php unset($__componentOriginal23a33f287873b564aaf305a1526eada4); ?>
<?php endif; ?>
<?php /**PATH D:\Data\laragon\Web\bba\resources\views/pages/kosakata.blade.php ENDPATH**/ ?>
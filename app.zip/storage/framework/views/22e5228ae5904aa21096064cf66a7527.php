<?php $__env->startPush('scripts'); ?>
    <script>
        function deleteData() {
            Swal.fire({
                title: "Anda yakin?",
                text: "Data yang terhapus tak dapat dikembalikan!",
                icon: "warning",
                showCancelButton: true,
                confirmButtonColor: "#d33",
                confirmButtonText: "Hapus!",
                cancelButtonText: "Batal"
            }).then((result) => {
                if (result.isConfirmed) {
                    $('#deleteForm').submit()
                }
            })
        }
    </script>
<?php $__env->stopPush(); ?>

<?php if (isset($component)) { $__componentOriginal23a33f287873b564aaf305a1526eada4 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal23a33f287873b564aaf305a1526eada4 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.layout','data' => ['title' => 'Detail Kosakata']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'Detail Kosakata']); ?>
    <div class="grid md:grid-cols-2 gap-4">
        <div class="card py-10 px-6 rounded-lg">
            <h1 class="font-bold text-xl">Kata</h1>
            <p class="text-3xl"><?php echo e($vocabulary->kata); ?></p>
            <p class="mb-4 text-xl"><?php echo e($vocabulary->latin); ?></p>

            <h1 class="font-bold text-xl">Arti</h1>
            <p class="mb-4 text-xl"><?php echo e($vocabulary->arti); ?></p>

            <h1 class="font-bold text-xl">Contoh Kalimat</h1>
            <p class="text-xl"><?php echo nl2br($vocabulary->contoh_kalimat); ?></p>

            <div class="flex justify-between mt-8">
                <button class="btn bg-primary text-white rounded"
                    onclick="document.location.href = '<?php echo e(route('kosakata.index')); ?>'">
                    <i class="uil uil-step-backward-alt"></i>
                </button>
                <div>
                    <button class="btn bg-success text-white rounded"
                        onclick="document.location.href = '<?php echo e(route('kosakata.edit', $vocabulary->id)); ?>'">
                        <i class="uil uil-edit"></i>
                    </button>
                    <form action="<?php echo e(route('kosakata.delete', $vocabulary->id)); ?>" method="post" id="deleteForm"
                        style="display: inline">
                        <?php echo method_field('DELETE'); ?>
                        <?php echo csrf_field(); ?>
                        <button type="button" class="btn bg-danger text-white rounded" onclick="deleteData()">
                            <i class="uil uil-trash"></i>
                        </button>
                    </form>
                </div>
            </div>
        </div>
        <div>
            <img src="<?php echo e(asset('assets/images/svg/lang.svg')); ?>" alt="">
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal23a33f287873b564aaf305a1526eada4)): ?>
<?php $attributes = $__attributesOriginal23a33f287873b564aaf305a1526eada4; ?>
<?php unset($__attributesOriginal23a33f287873b564aaf305a1526eada4); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal23a33f287873b564aaf305a1526eada4)): ?>
<?php $component = $__componentOriginal23a33f287873b564aaf305a1526eada4; ?>
<?php unset($__componentOriginal23a33f287873b564aaf305a1526eada4); ?>
<?php endif; ?>
<?php /**PATH D:\Data\laragon\Web\bba\resources\views/pages/kosakata-detail.blade.php ENDPATH**/ ?>
<div <?php echo e($attributes->merge(['class' => 'card p-6 rounded-lg'])); ?>>
    <?php echo e($slot); ?>

</div>
<?php /**PATH D:\Data\laragon\Web\bba\resources\views/components/elements/card.blade.php ENDPATH**/ ?>
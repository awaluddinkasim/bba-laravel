<?php if (isset($component)) { $__componentOriginal23a33f287873b564aaf305a1526eada4 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal23a33f287873b564aaf305a1526eada4 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.layout','data' => ['title' => 'Edit Pengguna']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'Edit Pengguna']); ?>

    <div class="grid md:grid-cols-2 gap-4">

        <img src="<?php echo e(asset('assets/images/account.svg')); ?>" alt="" style="max-width: 450px" class="mx-auto">

        <?php if (isset($component)) { $__componentOriginal4ed2e8f0d769c9d71ea4d41372d8c752 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal4ed2e8f0d769c9d71ea4d41372d8c752 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.elements.card','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('elements.card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>

            <form action="<?php echo e(route('users.update', $user->id)); ?>" method="post" autocomplete="off">
                <?php echo method_field('PATCH'); ?>
                <?php echo csrf_field(); ?>

                <div class="mb-3">
                    <label for="namaInput" class="text-gray-800 text-sm font-medium inline-block mb-2">Nama</label>
                    <input type="text" id="namaInput" name="nama"
                        class="form-input <?php $__errorArgs = ['nama'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-danger <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" value="<?php echo e($user->nama); ?>" required>
                </div>
                <div class="mb-3">
                    <label for="emailInput" class="text-gray-800 text-sm font-medium inline-block mb-2">Email</label>
                    <input type="email" id="emailInput" name="email"
                        class="form-input <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-danger <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" value="<?php echo e($user->email); ?>" required>
                </div>
                <div class="mb-3">
                    <label for="passwordInput" class="text-gray-800 text-sm font-medium inline-block mb-2">Ganti
                        Password</label>
                    <input type="password" id="passwordInput" name="password"
                        class="form-input <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-danger <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" value="">
                </div>

                <div class="mb-3">
                    <label for="jkInput" class="text-gray-800 text-sm font-medium inline-block mb-2">Jenis
                        Kelamin</label>
                    <select id="jkInput" name="jk" class="form-input <?php $__errorArgs = ['jk'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-danger <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                        required>
                        <option value="L" <?php echo e($user->jk == 'L' ? 'selected' : ''); ?>>Laki-laki</option>
                        <option value="P" <?php echo e($user->jk == 'P' ? 'selected' : ''); ?>>Perempuan</option>
                    </select>
                </div>
                <div class="mb-3">
                    <label for="noHPInput" class="text-gray-800 text-sm font-medium inline-block mb-2">No. HP</label>
                    <input type="text" id="noHPInput" name="no_hp"
                        class="form-input <?php $__errorArgs = ['no_hp'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-danger <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" value="<?php echo e($user->no_hp); ?>" required>
                </div>
                <button class="btn bg-primary text-white rounded mt-4" onclick="update()">Simpan</button>
            </form>

         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal4ed2e8f0d769c9d71ea4d41372d8c752)): ?>
<?php $attributes = $__attributesOriginal4ed2e8f0d769c9d71ea4d41372d8c752; ?>
<?php unset($__attributesOriginal4ed2e8f0d769c9d71ea4d41372d8c752); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal4ed2e8f0d769c9d71ea4d41372d8c752)): ?>
<?php $component = $__componentOriginal4ed2e8f0d769c9d71ea4d41372d8c752; ?>
<?php unset($__componentOriginal4ed2e8f0d769c9d71ea4d41372d8c752); ?>
<?php endif; ?>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal23a33f287873b564aaf305a1526eada4)): ?>
<?php $attributes = $__attributesOriginal23a33f287873b564aaf305a1526eada4; ?>
<?php unset($__attributesOriginal23a33f287873b564aaf305a1526eada4); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal23a33f287873b564aaf305a1526eada4)): ?>
<?php $component = $__componentOriginal23a33f287873b564aaf305a1526eada4; ?>
<?php unset($__componentOriginal23a33f287873b564aaf305a1526eada4); ?>
<?php endif; ?>
<?php /**PATH D:\Data\laragon\Web\bba\resources\views/pages/user-edit.blade.php ENDPATH**/ ?>
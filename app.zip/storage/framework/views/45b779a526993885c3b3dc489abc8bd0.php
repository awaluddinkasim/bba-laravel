<?php $__env->startPush('styles'); ?>
    <style>
        .cursor-pointer {
            cursor: pointer
        }
    </style>
<?php $__env->stopPush(); ?>

<?php if (isset($component)) { $__componentOriginal23a33f287873b564aaf305a1526eada4 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal23a33f287873b564aaf305a1526eada4 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.layout','data' => ['title' => 'Daftar Materi']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'Daftar Materi']); ?>
    <?php if (isset($component)) { $__componentOriginalca77f12175cc09adad5611cdec5ad84f = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalca77f12175cc09adad5611cdec5ad84f = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.elements.title','data' => ['class' => 'mb-3']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('elements.title'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'mb-3']); ?>
        Materi Terbaru
     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalca77f12175cc09adad5611cdec5ad84f)): ?>
<?php $attributes = $__attributesOriginalca77f12175cc09adad5611cdec5ad84f; ?>
<?php unset($__attributesOriginalca77f12175cc09adad5611cdec5ad84f); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalca77f12175cc09adad5611cdec5ad84f)): ?>
<?php $component = $__componentOriginalca77f12175cc09adad5611cdec5ad84f; ?>
<?php unset($__componentOriginalca77f12175cc09adad5611cdec5ad84f); ?>
<?php endif; ?>
    <?php $__empty_1 = true; $__currentLoopData = $daftarMateri; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $materi): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <div class="card p-5 rounded cursor-pointer mb-3"
            onclick="document.location.href = '<?php echo e(route('materi.show', $materi->id)); ?>'">
            <h1 class="font-bold text-xl">
                <?php echo e($materi->judul); ?>

            </h1>
            <small>Dibuat pada <?php echo e(Carbon\Carbon::parse($materi->created_at)->isoFormat('DD MMMM YYYY')); ?> pukul
                <?php echo e(Carbon\Carbon::parse($materi->created_at)->isoFormat('HH:mm')); ?></small>

            <p class="mt-3">
                <?php echo Str::limit(strip_tags($materi->konten), 250); ?>

            </p>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <div class="card text-center p-8 rounded-lg">
            Tidak ada materi
        </div>
    <?php endif; ?>

    <?php echo e($daftarMateri->links()); ?>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal23a33f287873b564aaf305a1526eada4)): ?>
<?php $attributes = $__attributesOriginal23a33f287873b564aaf305a1526eada4; ?>
<?php unset($__attributesOriginal23a33f287873b564aaf305a1526eada4); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal23a33f287873b564aaf305a1526eada4)): ?>
<?php $component = $__componentOriginal23a33f287873b564aaf305a1526eada4; ?>
<?php unset($__componentOriginal23a33f287873b564aaf305a1526eada4); ?>
<?php endif; ?>
<?php /**PATH D:\Data\laragon\Web\bba\resources\views/pages/materi.blade.php ENDPATH**/ ?>
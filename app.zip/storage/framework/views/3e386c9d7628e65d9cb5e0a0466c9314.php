<?php if (isset($component)) { $__componentOriginal23a33f287873b564aaf305a1526eada4 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal23a33f287873b564aaf305a1526eada4 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.layout','data' => ['title' => 'Tambah Kosakata']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'Tambah Kosakata']); ?>
    <div class="grid md:grid-cols-2 gap-6">
        <div>
            <img src="<?php echo e(asset('assets/images/svg/data.svg')); ?>" alt="">
        </div>
        <form action="<?php echo e(route('kosakata.update', $vocabulary->id)); ?>" method="post" autocomplete="off">
            <?php echo method_field('PATCH'); ?>
            <?php echo csrf_field(); ?>
            <div class="card p-6 rounded-lg">
                <div>
                    <div class="mb-3">
                        <label for="kataInput" class="text-gray-800 text-sm font-medium inline-block mb-2">Kata</label>
                        <input type="text" id="kataInput" name="kata"
                            class="form-input <?php $__errorArgs = ['kata'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-danger <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" value="<?php echo e($vocabulary->kata); ?>"
                            required>
                    </div>
                    <div class="mb-3">
                        <label for="latinInput"
                            class="text-gray-800 text-sm font-medium inline-block mb-2">Latin</label>
                        <input type="text" id="latinInput" name="latin"
                            class="form-input <?php $__errorArgs = ['latin'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-danger <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" value="<?php echo e($vocabulary->latin); ?>"
                            required>
                    </div>
                    <div class="mb-3">
                        <label for="artiInput" class="text-gray-800 text-sm font-medium inline-block mb-2">Arti</label>
                        <input type="text" id="artiInput" name="arti"
                            class="form-input <?php $__errorArgs = ['arti'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-danger <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" value="<?php echo e($vocabulary->arti); ?>"
                            required>
                    </div>
                    <div class="mb-3">
                        <label for="contohInput" class="text-gray-800 text-sm font-medium inline-block mb-2">Contoh
                            Kalimat</label>
                        <textarea name="contoh_kalimat" id="contohInput" rows="5"
                            class="form-input <?php $__errorArgs = ['contoh_kalimat'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-danger <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required><?php echo e($vocabulary->contoh_kalimat); ?></textarea>
                    </div>
                </div>

                <button class="btn bg-success text-white rounded">Simpan</button>
            </div>

        </form>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal23a33f287873b564aaf305a1526eada4)): ?>
<?php $attributes = $__attributesOriginal23a33f287873b564aaf305a1526eada4; ?>
<?php unset($__attributesOriginal23a33f287873b564aaf305a1526eada4); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal23a33f287873b564aaf305a1526eada4)): ?>
<?php $component = $__componentOriginal23a33f287873b564aaf305a1526eada4; ?>
<?php unset($__componentOriginal23a33f287873b564aaf305a1526eada4); ?>
<?php endif; ?>
<?php /**PATH D:\Data\laragon\Web\bba\resources\views/pages/kosakata-edit.blade.php ENDPATH**/ ?>
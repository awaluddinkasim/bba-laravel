<div {{ $attributes->merge(['class' => 'card p-6 rounded-lg']) }}>
    {{ $slot }}
</div>

<h1 {{ $attributes->merge(['class' => 'font-bold text-xl']) }}>
    {{ $slot }}
</h1>
